README - Saurus FakeKTP API (full package)
==========================================

Files included:
- fakektp.js       : main Vercel endpoint (root)
- package.json     : project info (module)
- vercel.json      : Vercel routing
- .gitignore
- fonts/           : place Helvetica.tts here (font NOT included)

IMPORTANT:
- This project generates DEMO mock images only. Do NOT use to create real identity documents.
- The Helvetica font file is NOT included due to licensing. Place your own font file at fonts/Helvetica.tts
  or edit fakektp.js to register a different font name.

How to deploy:
1. Add a TTF/TTF-like file named 'Helvetica.tts' into the fonts/ folder.
2. Push this repo to GitHub and deploy to Vercel, or upload zip to Vercel.
3. Call your api:
   https://<your-project>.vercel.app/api/fakektp?nama=Yourname&alamat=Jlan%20Disana&agama=Agamamu&kawin=Statuskawin
