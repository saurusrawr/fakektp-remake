import { createCanvas, registerFont } from 'canvas';
import path from 'path';
import { fileURLToPath } from 'url';

// Resolve __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Register Helvetica font (place Helvetica.tts in /fonts)
try {
  registerFont(path.join(__dirname, 'fonts', 'Helvetica.tts'), { family: 'Helvetica' });
} catch (e) {
  console.warn('Helvetica font not found. Please add fonts/Helvetica.tts. Using fallback fonts may cause missing glyphs.');
}

function randomNik() {
  let digits = '';
  for (let i = 0; i < 12; i++) digits += Math.floor(Math.random() * 10).toString();
  return `FAKE-${digits}`;
}

function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
  const words = String(text).split(' ');
  let line = '';
  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    const testWidth = metrics.width;
    if (testWidth > maxWidth && n > 0) {
      ctx.fillText(line.trim(), x, y);
      line = words[n] + ' ';
      y += lineHeight;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line.trim(), x, y);
}

export default async function handler(req, res) {
  try {
    const q = req.method === 'GET' ? req.query : (await new Promise(r => {
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => r(JSON.parse(body || '{}')));
    }));

    const nameRaw = q.nama || q.name || 'NAMA LENGKAP';
    const alamatRaw = q.alamat || q.address || 'ALAMAT DEMO, KOTA';
    const agamaRaw = q.agama || q.religion || 'AGAMA';
    const kawinRaw = q.kawin || q.status || 'BELUM';

    const name = String(nameRaw).toUpperCase();
    const alamat = String(alamatRaw);
    const agama = String(agamaRaw);
    const kawin = String(kawinRaw);

    const nik = q.nik || randomNik();

    const W = 1000;
    const H = 620;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    // Background
    ctx.fillStyle = '#f3f7fb';
    ctx.fillRect(0, 0, W, H);

    const pad = 40;
    const cardW = W - pad * 2;
    const cardH = H - pad * 2;

    // Card
    ctx.fillStyle = '#fff';
    ctx.fillRect(pad, pad, cardW, cardH);

    // Header band
    ctx.fillStyle = '#0b5ea8';
    ctx.fillRect(pad, pad, cardW, 110);

    // Title
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 36px Helvetica';
    ctx.fillText('KARTU IDENTITAS DEMO', pad + 24, pad + 70);

    // Left column
    ctx.fillStyle = '#111827';
    ctx.font = 'bold 20px Helvetica';
    ctx.fillText('NIK', pad + 24, pad + 160);
    ctx.font = '20px Helvetica';
    ctx.fillText(String(nik), pad + 24, pad + 190);

    ctx.font = 'bold 20px Helvetica';
    ctx.fillText('Nama', pad + 24, pad + 230);
    ctx.font = '20px Helvetica';
    wrapText(ctx, name, pad + 24, pad + 260, 520, 26);

    ctx.font = 'bold 20px Helvetica';
    ctx.fillText('Alamat', pad + 24, pad + 320);
    ctx.font = '18px Helvetica';
    wrapText(ctx, alamat, pad + 24, pad + 350, 520, 22);

    ctx.font = 'bold 20px Helvetica';
    ctx.fillText('Agama', pad + 24, pad + 420);
    ctx.font = '18px Helvetica';
    ctx.fillText(agama, pad + 24, pad + 450);

    ctx.font = 'bold 20px Helvetica';
    ctx.fillText('Status Pernikahan', pad + 24, pad + 500);
    ctx.font = '18px Helvetica';
    ctx.fillText(kawin, pad + 24, pad + 530);

    // Photo placeholder (kanan)
    const photoW = 220;
    const photoH = 280;
    const photoX = W - pad - photoW - 10;
    const photoY = pad + 140;
    ctx.fillStyle = '#dbe7ff';
    ctx.fillRect(photoX, photoY, photoW, photoH);
    ctx.fillStyle = '#5b6b95';
    ctx.font = 'bold 20px Helvetica';
    ctx.fillText('FOTO', photoX + 70, photoY + photoH / 2);

    // Footer note
    ctx.fillStyle = '#6b7280';
    ctx.font = '14px Helvetica';
    ctx.fillText('Hanya contoh / demo — BUKAN DOKUMEN RESMI', pad + 24, H - pad - 20);

    // Big SAMPLE watermark diagonal
    ctx.save();
    ctx.translate(W / 2, H / 2);
    ctx.rotate(-0.35);
    ctx.fillStyle = 'rgba(200,20,20,0.12)';
    ctx.font = 'bold 96px Helvetica';
    ctx.textAlign = 'center';
    ctx.fillText('SAMPLE', 0, 0);
    ctx.restore();

    // Border
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#cfd8e3';
    ctx.strokeRect(pad, pad, cardW, cardH);

    const buffer = canvas.toBuffer('image/png');
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('X-Generated-By', 'ZEPHYRA-DEMO-FakeKTP-API');
    res.status(200).send(buffer);

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error', detail: err.message });
  }
}
